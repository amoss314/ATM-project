package edu.umsl.lastprojectatm;

import java.io.BufferedReader;

import java.io.InputStreamReader;



public class ATM {

	
	public static void main(String[] args) throws Exception {
		BufferedReader reader = null;
		System.out.println("Press 1 to add money, 2 to take out money, 3 to get current balance");
		
		reader = new BufferedReader(new InputStreamReader(System.in));
		int s = Integer.parseInt(reader.readLine());
		switch (s) {
		case 1: 
				addBalance();
				break;
				
		case 2:
				decreaseBalance();
				break;
				
		case 3:
				currentBalance();
				break;
				
		}
	}
				
		public static void currentBalance() throws Exception{
			int currentbalance = readFromFile();
			System.out.println("Current Balance: " +currentbalance);
		}
		
	
	
	
		public static void addBalance() throws Exception{
			BufferedReader reader = null;
			System.out.println("How much do you wish to add?");
			reader = new BufferedReader(new InputStreamReader(System.in));
			int s = Integer.parseInt(reader.readLine());
			int currentbalance = readFromFile();
			System.out.println("Current Balance: " +currentbalance);
			int newBalance = s+currentbalance;
			System.out.println("New Balance: " +newBalance);
			
		writeToFile(newBalance);
		}
		
		
		private static int writeToFile(int newBalance) {
			
			return 0;
		}

		public static void decreaseBalance() throws Exception{
			BufferedReader reader = null;
			System.out.println("How much do you wish to withdraw?");
			reader = new BufferedReader(new InputStreamReader(System.in));
			int s = Integer.parseInt(reader.readLine());
			int currentbalance = readFromFile();
			System.out.print("Current Balance: " +currentbalance);
			int newbalance = currentbalance-s;
			System.out.println("New Balance: " +newbalance);
			
			writeToFile(newbalance);
	
			
		}

		private static int readFromFile() {
			// TODO Auto-generated method stub
			return 0;
		}
}
			